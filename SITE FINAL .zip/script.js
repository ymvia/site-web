"use strict";

const openMenuButton = document.querySelector("button.openMenu");
const closeMenuButton = document.querySelector("button.closeMenu");
const menuEl = document.querySelector("nav.nav-screen");

openMenuButton.addEventListener("click", () => {
  menuEl.classList.add("open");
});

closeMenuButton.addEventListener("click", () => {
  menuEl.classList.remove("open");
});
